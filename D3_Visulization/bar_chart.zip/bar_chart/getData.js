import { csv } from 'd3';

//const csvUrl = 'https://gist.githubusercontent.com/Samic25/8e63612895fd0089b1b405676dc5ca1b/raw/test.csv';

export const getData = async () => {
  const data = await csv("data.csv");
  
  // Have a look at the attributes available in the console!
  console.log(data[0]);

  return data;
};