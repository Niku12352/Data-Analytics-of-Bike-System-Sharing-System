import vl from 'vega-lite-api';
export const viz = vl
  .markBar()
  .encode(
    vl.x().fieldN('Quarter'),
    vl.y().count(),
    vl.color().fieldN('member_casual'),
    vl.tooltip(['year',vl.y().count()])
    
  );