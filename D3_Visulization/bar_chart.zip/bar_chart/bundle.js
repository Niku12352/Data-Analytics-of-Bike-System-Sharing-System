(function (vega, vegaLite, vl, vegaTooltip, d3) {
  'use strict';

  vega = vega && Object.prototype.hasOwnProperty.call(vega, 'default') ? vega['default'] : vega;
  vegaLite = vegaLite && Object.prototype.hasOwnProperty.call(vegaLite, 'default') ? vegaLite['default'] : vegaLite;
  vl = vl && Object.prototype.hasOwnProperty.call(vl, 'default') ? vl['default'] : vl;

  const dark = '#3e3c38';
  const config = {
    axis: {
      domain: false,
      tickColor: 'lightGray'
    },
    style: {
      "guide-label": {
        fontSize: 20,
        fill: dark
      },
      "guide-title": {
        fontSize: 30,
        fill: dark
      }
    }
  };

  //const csvUrl = 'https://gist.githubusercontent.com/Samic25/8e63612895fd0089b1b405676dc5ca1b/raw/test.csv';

  const getData = async () => {
    const data = await d3.csv("data.csv");
    
    // Have a look at the attributes available in the console!
    console.log(data[0]);

    return data;
  };

  const viz = vl
    .markBar()
    .encode(
      vl.x().fieldN('Quarter'),
      vl.y().count(),
      vl.color().fieldN('type'),
      vl.tooltip(['year'])
      
    );

  vl.register(vega, vegaLite, {
    view: { renderer: 'svg' },
    init: view => { view.tooltip(new vegaTooltip.Handler().call); }
  });

  const run = async () => {
    const marks = viz
      .data(await getData())
      .width(window.innerWidth)
      .height(window.innerHeight)
      .autosize({ type: 'fit', contains: 'padding' })
      .config(config);
    
    document.body.appendChild(await marks.render());
  };
  run();

}(vega, vegaLite, vl, vegaTooltip, d3));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbImNvbmZpZy5qcyIsImdldERhdGEuanMiLCJ2aXouanMiLCJpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBkYXJrID0gJyMzZTNjMzgnO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IHtcbiAgYXhpczoge1xuICAgIGRvbWFpbjogZmFsc2UsXG4gICAgdGlja0NvbG9yOiAnbGlnaHRHcmF5J1xuICB9LFxuICBzdHlsZToge1xuICAgIFwiZ3VpZGUtbGFiZWxcIjoge1xuICAgICAgZm9udFNpemU6IDIwLFxuICAgICAgZmlsbDogZGFya1xuICAgIH0sXG4gICAgXCJndWlkZS10aXRsZVwiOiB7XG4gICAgICBmb250U2l6ZTogMzAsXG4gICAgICBmaWxsOiBkYXJrXG4gICAgfVxuICB9XG59OyIsImltcG9ydCB7IGNzdiB9IGZyb20gJ2QzJztcblxuLy9jb25zdCBjc3ZVcmwgPSAnaHR0cHM6Ly9naXN0LmdpdGh1YnVzZXJjb250ZW50LmNvbS9TYW1pYzI1LzhlNjM2MTI4OTVmZDAwODliMWI0MDU2NzZkYzVjYTFiL3Jhdy90ZXN0LmNzdic7XG5cbmV4cG9ydCBjb25zdCBnZXREYXRhID0gYXN5bmMgKCkgPT4ge1xuICBjb25zdCBkYXRhID0gYXdhaXQgY3N2KFwiZGF0YS5jc3ZcIik7XG4gIFxuICAvLyBIYXZlIGEgbG9vayBhdCB0aGUgYXR0cmlidXRlcyBhdmFpbGFibGUgaW4gdGhlIGNvbnNvbGUhXG4gIGNvbnNvbGUubG9nKGRhdGFbMF0pO1xuXG4gIHJldHVybiBkYXRhO1xufTsiLCJpbXBvcnQgdmwgZnJvbSAndmVnYS1saXRlLWFwaSc7XG5leHBvcnQgY29uc3Qgdml6ID0gdmxcbiAgLm1hcmtCYXIoKVxuICAuZW5jb2RlKFxuICAgIHZsLngoKS5maWVsZE4oJ1F1YXRlcl8xJyksXG4gICAgdmwueSgpLmNvdW50KCksXG4gICAgdmwuY29sb3IoKS5maWVsZE4oJ21lbWJlcl9jYXN1YWwnKSxcbiAgICB2bC50b29sdGlwKFsneWVhciddKVxuICAgIFxuICApOyIsImltcG9ydCB2ZWdhIGZyb20gJ3ZlZ2EnO1xuaW1wb3J0IHZlZ2FMaXRlIGZyb20gJ3ZlZ2EtbGl0ZSc7XG5pbXBvcnQgdmwgZnJvbSAndmVnYS1saXRlLWFwaSc7XG5pbXBvcnQgeyBIYW5kbGVyIH0gZnJvbSAndmVnYS10b29sdGlwJztcbmltcG9ydCB7IGNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcbmltcG9ydCB7IGdldERhdGEgfSBmcm9tICcuL2dldERhdGEnO1xuaW1wb3J0IHsgdml6IH0gZnJvbSAnLi92aXonO1xuXG52bC5yZWdpc3Rlcih2ZWdhLCB2ZWdhTGl0ZSwge1xuICB2aWV3OiB7IHJlbmRlcmVyOiAnc3ZnJyB9LFxuICBpbml0OiB2aWV3ID0+IHsgdmlldy50b29sdGlwKG5ldyBIYW5kbGVyKCkuY2FsbCk7IH1cbn0pO1xuXG5jb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IG1hcmtzID0gdml6XG4gICAgLmRhdGEoYXdhaXQgZ2V0RGF0YSgpKVxuICAgIC53aWR0aCh3aW5kb3cuaW5uZXJXaWR0aClcbiAgICAuaGVpZ2h0KHdpbmRvdy5pbm5lckhlaWdodClcbiAgICAuYXV0b3NpemUoeyB0eXBlOiAnZml0JywgY29udGFpbnM6ICdwYWRkaW5nJyB9KVxuICAgIC5jb25maWcoY29uZmlnKTtcbiAgXG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYXdhaXQgbWFya3MucmVuZGVyKCkpO1xufTtcbnJ1bigpOyJdLCJuYW1lcyI6WyJjc3YiLCJIYW5kbGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0VBQUEsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDO0VBQ2hCLE1BQU0sTUFBTSxHQUFHO0VBQ3RCLEVBQUUsSUFBSSxFQUFFO0VBQ1IsSUFBSSxNQUFNLEVBQUUsS0FBSztFQUNqQixJQUFJLFNBQVMsRUFBRSxXQUFXO0VBQzFCLEdBQUc7RUFDSCxFQUFFLEtBQUssRUFBRTtFQUNULElBQUksYUFBYSxFQUFFO0VBQ25CLE1BQU0sUUFBUSxFQUFFLEVBQUU7RUFDbEIsTUFBTSxJQUFJLEVBQUUsSUFBSTtFQUNoQixLQUFLO0VBQ0wsSUFBSSxhQUFhLEVBQUU7RUFDbkIsTUFBTSxRQUFRLEVBQUUsRUFBRTtFQUNsQixNQUFNLElBQUksRUFBRSxJQUFJO0VBQ2hCLEtBQUs7RUFDTCxHQUFHO0VBQ0gsQ0FBQzs7RUNkRDtBQUNBO0VBQ08sTUFBTSxPQUFPLEdBQUcsWUFBWTtFQUNuQyxFQUFFLE1BQU0sSUFBSSxHQUFHLE1BQU1BLE1BQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUNyQztFQUNBO0VBQ0EsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCO0VBQ0EsRUFBRSxPQUFPLElBQUksQ0FBQztFQUNkLENBQUM7O0VDVk0sTUFBTSxHQUFHLEdBQUcsRUFBRTtFQUNyQixHQUFHLE9BQU8sRUFBRTtFQUNaLEdBQUcsTUFBTTtFQUNULElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7RUFDN0IsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFO0VBQ2xCLElBQUksRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUM7RUFDdEMsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7RUFDeEI7RUFDQSxHQUFHOztFQ0RILEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRTtFQUM1QixFQUFFLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUU7RUFDM0IsRUFBRSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJQyxtQkFBTyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRTtFQUNyRCxDQUFDLENBQUMsQ0FBQztBQUNIO0VBQ0EsTUFBTSxHQUFHLEdBQUcsWUFBWTtFQUN4QixFQUFFLE1BQU0sS0FBSyxHQUFHLEdBQUc7RUFDbkIsS0FBSyxJQUFJLENBQUMsTUFBTSxPQUFPLEVBQUUsQ0FBQztFQUMxQixLQUFLLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0VBQzdCLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7RUFDL0IsS0FBSyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQztFQUNuRCxLQUFLLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUNwQjtFQUNBLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztFQUNsRCxDQUFDLENBQUM7RUFDRixHQUFHLEVBQUU7Ozs7In0=